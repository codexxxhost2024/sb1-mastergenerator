import { Inter } from 'next/font/google'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'Panyero Movies',
  description: 'Your maritime entertainment hub',
}

export default function MovieLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className={`${inter.className} min-h-screen bg-[#121212]`}>
      {children}
    </div>
  )
}

