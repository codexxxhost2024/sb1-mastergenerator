import MovieNavbar from '../../components/movie/MovieNavbar'
import MovieSidebar from '../../components/movie/MovieSidebar'
import MovieContent from '../../components/movie/MovieContent'

export default function MoviePage() {
  return (
    <div className="flex h-screen">
      <MovieSidebar />
      <div className="flex-1 flex flex-col">
        <MovieNavbar />
        <MovieContent />
      </div>
    </div>
  )
}

