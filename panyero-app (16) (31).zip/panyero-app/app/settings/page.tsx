'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Header from '../../components/Header'
import NavigationBar from '../../components/NavigationBar'
import { Button } from '@/components/ui/button'
import { useAuth } from '../../contexts/AuthContext'
import { doc, updateDoc } from 'firebase/firestore'
import { db } from '../../firebase'

export default function SettingsPage() {
  const { user, setUser } = useAuth()
  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [phoneNumber, setPhoneNumber] = useState('')
  const [isAdmin, setIsAdmin] = useState(false)
  const router = useRouter()

  useEffect(() => {
    if (user) {
      setEmail(user.email || '')
      setName(user.displayName || '')
      setPhoneNumber(user.phoneNumber || '')
      setIsAdmin(user.email === 'admin@panyero.website')
    }
  }, [user])

  const handleAdminAccess = () => {
    router.push('/admin')
  }

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    const userRef = doc(db, 'users', user.id)
    const updatedUser = {
      ...user,
      email,
      displayName: name,
      phoneNumber,
    }
    await updateDoc(userRef, { email, displayName: name, phoneNumber })
    setUser(updatedUser)
    alert('Profile updated successfully!')
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f9fa] to-[#e9ecef] p-4 pb-24">
      <Header userLevel={5} />
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-4 text-[#1a237e]">Settings</h1>
        <p className="text-gray-600 mb-6">Manage your account settings and preferences for the Panyero app.</p>
        
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Account Settings</h2>
          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              />
            </div>
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
              <input
                type="text"
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              />
            </div>
            <div>
              <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700">Phone Number</label>
              <input
                type="tel"
                id="phoneNumber"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              />
            </div>
            <Button type="submit" className="w-full">Update Profile</Button>
          </form>
        </div>

        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Preferences</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Language</label>
              <select className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                <option>English</option>
                <option>Filipino</option>
                <option>Cebuano</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Notifications</label>
              <div className="mt-2">
                <label className="inline-flex items-center">
                  <input type="checkbox" className="form-checkbox h-5 w-5 text-indigo-600" defaultChecked />
                  <span className="ml-2 text-gray-700">Email notifications</span>
                </label>
              </div>
              <div className="mt-2">
                <label className="inline-flex items-center">
                  <input type="checkbox" className="form-checkbox h-5 w-5 text-indigo-600" defaultChecked />
                  <span className="ml-2 text-gray-700">Push notifications</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        {isAdmin && (
          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <h2 className="text-xl font-semibold mb-4">Admin Access</h2>
            <Button onClick={handleAdminAccess} className="w-full bg-red-600 hover:bg-red-700">
              Access Admin Dashboard
            </Button>
          </div>
        )}
      </div>
      <NavigationBar />
    </div>
  )
}

