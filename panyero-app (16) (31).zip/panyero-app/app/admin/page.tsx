'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Header from '../../components/Header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useAuth } from '../../contexts/AuthContext'
import { collection, getDocs, doc, updateDoc, increment, addDoc } from 'firebase/firestore'
import { db } from '../../firebase'
import { Switch } from '@/components/ui/switch'

interface User {
  id: string
  name: string
  email: string
  balance: number
  isAffiliate: boolean
  phoneNumber: string
}

interface Service {
  id: string
  icon: string
  title: string
  url: string
  isActive: boolean
}

export default function AdminPage() {
  const [users, setUsers] = useState<User[]>([])
  const [services, setServices] = useState<Service[]>([])
  const [newService, setNewService] = useState({ icon: '', title: '', url: '', isActive: true })
  const { user } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (user?.email !== 'admin@panyero.website') {
      router.push('/')
    } else {
      fetchUsers()
      fetchServices()
    }
  }, [user, router])

  const fetchUsers = async () => {
    const usersCollection = collection(db, 'users')
    const userSnapshot = await getDocs(usersCollection)
    const userList = userSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as User))
    setUsers(userList)
  }

  const fetchServices = async () => {
    const servicesCollection = collection(db, 'services')
    const serviceSnapshot = await getDocs(servicesCollection)
    const serviceList = serviceSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Service))
    setServices(serviceList)
  }

  const handleSendMoney = async (userId: string, amount: number) => {
    const userRef = doc(db, 'users', userId)
    await updateDoc(userRef, {
      balance: increment(amount)
    })
    fetchUsers()
  }

  const handleRevokeBalance = async (userId: string, amount: number) => {
    const userRef = doc(db, 'users', userId)
    await updateDoc(userRef, {
      balance: increment(-amount)
    })
    fetchUsers()
  }

  const handleAddService = async () => {
    const servicesCollection = collection(db, 'services')
    await addDoc(servicesCollection, newService)
    setNewService({ icon: '', title: '', url: '', isActive: true })
    fetchServices()
  }

  const handleToggleAffiliate = async (userId: string, isAffiliate: boolean) => {
    const userRef = doc(db, 'users', userId)
    await updateDoc(userRef, { isAffiliate })
    fetchUsers()
  }

  const handleToggleService = async (serviceId: string, isActive: boolean) => {
    const serviceRef = doc(db, 'services', serviceId)
    await updateDoc(serviceRef, { isActive })
    fetchServices()
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f9fa] to-[#e9ecef] p-4">
      <Header userLevel={5} />
      <h1 className="text-2xl font-bold mb-6 text-[#1a237e]">Admin Dashboard</h1>

      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">User Management</h2>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Balance</TableHead>
              <TableHead>Affiliate</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.map((user) => (
              <TableRow key={user.id}>
                <TableCell>{user.name}</TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>₱{user.balance.toFixed(2)}</TableCell>
                <TableCell>
                  <Switch
                    checked={user.isAffiliate}
                    onCheckedChange={(checked) => handleToggleAffiliate(user.id, checked)}
                  />
                </TableCell>
                <TableCell>
                  <Button onClick={() => handleSendMoney(user.id, 100)} className="mr-2">Send ₱100</Button>
                  <Button onClick={() => handleRevokeBalance(user.id, 100)} variant="destructive">Revoke ₱100</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">Services Management</h2>
        <div className="grid grid-cols-4 gap-4 mb-4">
          <Input
            placeholder="Icon URL"
            value={newService.icon}
            onChange={(e) => setNewService({ ...newService, icon: e.target.value })}
          />
          <Input
            placeholder="Title"
            value={newService.title}
            onChange={(e) => setNewService({ ...newService, title: e.target.value })}
          />
          <Input
            placeholder="Destination URL"
            value={newService.url}
            onChange={(e) => setNewService({ ...newService, url: e.target.value })}
          />
          <Button onClick={handleAddService}>Add Service</Button>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Icon</TableHead>
              <TableHead>Title</TableHead>
              <TableHead>URL</TableHead>
              <TableHead>Active</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {services.map((service) => (
              <TableRow key={service.id}>
                <TableCell>
                  <img src={service.icon} alt={service.title} className="w-8 h-8" />
                </TableCell>
                <TableCell>{service.title}</TableCell>
                <TableCell>{service.url}</TableCell>
                <TableCell>
                  <Switch
                    checked={service.isActive}
                    onCheckedChange={(checked) => handleToggleService(service.id, checked)}
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

