import Header from '../../components/Header'
import NavigationBar from '../../components/NavigationBar'

export default function WalletPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f9fa] to-[#e9ecef] p-4 pb-24">
      <Header userLevel={5} />
      <h1 className="text-2xl font-bold mb-4 text-[#1a237e]">Wallet</h1>
      <p className="text-gray-600">Manage your digital wallet and make quick transfers.</p>
      {/* Add wallet balance and transfer functionality here */}
      <NavigationBar />
    </div>
  )
}

