import Header from '../../components/Header'
import NavigationBar from '../../components/NavigationBar'
import UserProfile from '../../components/UserProfile'
import QRCodeComponent from '../../components/QRCodeComponent'

export default function Profile() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f9fa] to-[#e9ecef] p-4 pb-24">
      <Header userLevel={5} />
      <UserProfile />
      <div className="mt-6">
        <h2 className="text-xl font-semibold mb-4 text-[#1a237e]">Your QR Code</h2>
        <QRCodeComponent />
      </div>
      <NavigationBar />
    </div>
  )
}

