import Header from '../../components/Header'
import NavigationBar from '../../components/NavigationBar'
import MaritimeServices from '../../components/MaritimeServices'

export default function Maritime() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f9fa] to-[#e9ecef] p-4 pb-24">
      <Header userLevel={5} />
      <MaritimeServices />
      <NavigationBar />
    </div>
  )
}

