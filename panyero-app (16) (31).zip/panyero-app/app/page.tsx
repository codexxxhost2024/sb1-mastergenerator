'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '../contexts/AuthContext'
import Header from '../components/Header'
import WalletBalance from '../components/WalletBalance'
import KapitanNiyero from '../components/KapitanNiyero'
import QuickAccess from '../components/QuickAccess'
import RecentTransactions from '../components/RecentTransactions'
import UserProfiles from '../components/UserProfiles'
import NavigationButtons from '../components/NavigationButtons'
import VoiceAssistant from '../components/VoiceAssistant'
import NavigationBar from '../components/NavigationBar'

export default function Home() {
  const { user } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (user && !user.displayName) {
      router.push('/update-profile')
    }
  }, [user, router])

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f9fa] to-[#e9ecef] p-4 pb-24">
      <Header userLevel={5} />
      <WalletBalance initialBalance={user.balance} />
      <KapitanNiyero />
      <QuickAccess />
      <RecentTransactions />
      <UserProfiles />
      <NavigationButtons weatherAlert="Clear skies ahead" />
      <VoiceAssistant />
      <NavigationBar />
    </div>
  )
}

