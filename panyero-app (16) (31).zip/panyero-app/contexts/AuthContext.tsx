import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { doc, getDoc, setDoc } from 'firebase/firestore'
import { db } from '../firebase'
import { v4 as uuidv4 } from 'uuid'

interface User {
  id: string
  displayName: string
  email: string
  isVerified: boolean
  balance: number
  isAffiliate: boolean
  phoneNumber: string
}

interface AuthContextType {
  user: User | null
  setUser: (user: User | null) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null)

  useEffect(() => {
    const getOrCreateUser = async () => {
      let deviceId = localStorage.getItem('deviceId')
      if (!deviceId) {
        deviceId = uuidv4()
        localStorage.setItem('deviceId', deviceId)
      }

      const userRef = doc(db, 'users', deviceId)
      const userDoc = await getDoc(userRef)

      if (!userDoc.exists()) {
        const newUser: User = {
          id: deviceId,
          displayName: 'New User',
          email: '',
          isVerified: false,
          balance: 0,
          isAffiliate: false,
          phoneNumber: '',
        }
        await setDoc(userRef, newUser)
        setUser(newUser)
      } else {
        setUser(userDoc.data() as User)
      }
    }

    getOrCreateUser()
  }, [])

  return (
    <AuthContext.Provider value={{ user, setUser }}>
      {children}
    </AuthContext.Provider>
  )
}

