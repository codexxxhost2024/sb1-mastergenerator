import { FC } from 'react'
import { Stethoscope, GraduationCap, Briefcase, Laptop, Palette, Film, Anchor, Shield, FlaskRoundIcon as Flask, Wrench, ChefHat, Dumbbell, Wheat, Scale, Truck, Bot, Music, Video, Image, FileText, Database, Lock, AppleIcon as Jobs, Train, Newspaper, HelpCircle, Gamepad, Trophy, FileSearch, Headphones, School, Bell, Calendar, Map, Users, Package, Fuel, PenToolIcon as Tool, Radio, FilesIcon as Docs, Umbrella, Award, Building, BanknoteIcon as Bank, ShoppingCart, Utensils, Car, Plane, Home, Gavel, PuzzleIcon as Mahjong, Dice1Icon as Dice, PuzzleIcon as Chess, Hash, PuzzleIcon as Quiz, Puzzle, Joystick, ClubIcon as Football, Ticket, Cloud, WavesIcon as Wave, AlertTriangle, Zap, Droplet, Wifi, Tv, TrendingUp, Smartphone, CreditCard, SpadeIcon as Spades, CircleDot, WalletCardsIcon as Cards, Grid, Grid3X3, Star, Clock, Gift, MapPin } from 'lucide-react'
import { useMediaQuery } from 'react-responsive'
import { useState } from 'react';

interface Service {
  icon: React.ElementType;
  title: string;
}

interface Category {
  name: string;
  services: Service[];
}

const categories: Category[] = [
  {
    name: "General Services",
    services: [
      { icon: Stethoscope, title: 'Medical' },
      { icon: GraduationCap, title: 'Education' },
      { icon: Briefcase, title: 'Business' },
      { icon: Laptop, title: 'Technology' },
      { icon: Palette, title: 'Arts' },
      { icon: Film, title: 'Entertainment' },
      { icon: Anchor, title: 'Maritime' },
      { icon: Shield, title: 'Government' },
    ]
  },
  {
    name: "AI Services",
    services: [
      { icon: Bot, title: 'AI Assistant' },
      { icon: FileText, title: 'AI Chat' },
      { icon: Quiz, title: 'AI Quiz' },
      { icon: FileSearch, title: 'AI Document' },
      { icon: Headphones, title: 'AI Transcription' },
      { icon: School, title: 'AI Learning' },
      { icon: Bell, title: 'AI Notifications' },
      { icon: Calendar, title: 'AI Calendar' },
    ]
  },
  {
    name: "Maritime Services",
    services: [
      { icon: Map, title: 'Navigation' },
      { icon: Cloud, title: 'Weather' },
      { icon: Wave, title: 'Tides' },
      { icon: AlertTriangle, title: 'SOS' },
      { icon: Users, title: 'Crew' },
      { icon: Package, title: 'Cargo' },
      { icon: Fuel, title: 'Fuel' },
      { icon: Tool, title: 'Maintenance' },
    ]
  },
  {
    name: "E-Services",
    services: [
      { icon: Building, title: 'Government' },
      { icon: Bank, title: 'Banking' },
      { icon: ShoppingCart, title: 'Shopping' },
      { icon: Utensils, title: 'Food' },
      { icon: Car, title: 'Transportation' },
      { icon: Plane, title: 'Travel' },
      { icon: Home, title: 'Real Estate' },
      { icon: Gavel, title: 'Legal' },
    ]
  },
  {
    name: "Entertainment",
    services: [
      { icon: Gamepad, title: 'Games' },
      { icon: Trophy, title: 'E-Sports' },
      { icon: Mahjong, title: 'Mahjong' },
      { icon: Dice, title: 'Dice Games' },
      { icon: Chess, title: 'Chess' },
      { icon: Football, title: 'Sports' },
      { icon: Music, title: 'Music' },
      { icon: Tv, title: 'TV' },
    ]
  },
]

const EServicesContent: FC = () => {
  const isMobile = useMediaQuery({ maxWidth: 767 })
  const [selectedService, setSelectedService] = useState<string | null>(null)

  const handleServiceClick = (title: string) => {
    setSelectedService(title)
  }

  const handleCloseEmbed = () => {
    setSelectedService(null)
  }

  return (
    <>
      {categories.map((category, categoryIndex) => (
        <div key={categoryIndex} className="mb-8">
          <h2 className="text-xl font-semibold text-[#1a237e] mb-4">{category.name}</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {category.services.map((service, serviceIndex) => (
              <div
                key={serviceIndex}
                className="flex flex-col items-center justify-center p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => handleServiceClick(service.title)}
              >
                <service.icon className="w-8 h-8 text-[#1a237e] mb-2" />
                <span className="text-sm font-medium text-center">{service.title}</span>
              </div>
            ))}
          </div>
        </div>
      ))}
      {isMobile && selectedService && (
        <div className="fixed inset-0 z-50 bg-black">
          <div className="relative w-full h-full">
            <iframe
              src={`https://panyero.website/movie/${selectedService.toLowerCase().replace(/\s+/g, '-')}`}
              className="w-full h-full"
              style={{ border: 'none' }}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
            <button
              className="absolute top-4 right-4 bg-white text-black p-2 rounded-full"
              onClick={handleCloseEmbed}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  )
}

export default EServicesContent

