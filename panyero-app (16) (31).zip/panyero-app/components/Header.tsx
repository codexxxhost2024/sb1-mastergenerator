import { FC } from 'react'
import { Bell, UserCircle } from 'lucide-react'

interface HeaderProps {
  userLevel: number
}

const Header: FC<HeaderProps> = ({ userLevel }) => {
  return (
    <header className="flex items-center justify-between mb-6">
      <div className="flex items-center gap-2">
        <h1 className="text-2xl font-bold font-roboto text-[#1a237e]">Panyero</h1>
        <span className="bg-[#1a237e] text-white text-xs px-2 py-1 rounded-full">Lvl {userLevel}</span>
      </div>
      <div className="flex items-center gap-4">
        <div className="relative">
          <Bell className="text-[#1a237e] text-xl cursor-pointer hover:text-blue-600 transition-colors" />
          <span className="absolute -top-1 -right-1 bg-red-500 w-2 h-2 rounded-full"></span>
        </div>
        <UserCircle className="text-[#1a237e] text-2xl cursor-pointer hover:text-blue-600 transition-colors" />
      </div>
    </header>
  )
}

export default Header

