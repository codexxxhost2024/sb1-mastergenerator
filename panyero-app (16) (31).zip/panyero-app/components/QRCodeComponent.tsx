import React from 'react'
import { QRCodeSVG } from 'qrcode.react'
import { Lock } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'

const QRCodeComponent: React.FC = () => {
  const { user } = useAuth()

  if (!user) {
    return null
  }

  const qrValue = user.isAffiliate ? `PANYERO:${user.phoneNumber}` : ''

  return (
    <div className="relative w-48 h-48 mx-auto">
      {user.isAffiliate ? (
        <QRCodeSVG
          value={qrValue}
          size={192}
          level="H"
          includeMargin={true}
        />
      ) : (
        <>
          <div className="absolute inset-0 backdrop-blur-md flex items-center justify-center">
            <Lock className="w-12 h-12 text-gray-500" />
          </div>
          <QRCodeSVG
            value=""
            size={192}
            level="H"
            includeMargin={true}
          />
        </>
      )}
    </div>
  )
}

export default QRCodeComponent

