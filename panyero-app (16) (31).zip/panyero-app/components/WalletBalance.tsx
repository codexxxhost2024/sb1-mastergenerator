'use client'

import { FC, useState } from 'react'
import { Eye, Plus, Send } from 'lucide-react'
import SendMoneyModal from './SendMoneyModal'
import CashInModal from './CashInModal'
import { useAuth } from '../contexts/AuthContext'

interface WalletBalanceProps {
  initialBalance: number;
}

const WalletBalance: FC<WalletBalanceProps> = ({ initialBalance }) => {
  const [balance, setBalance] = useState(initialBalance)
  const [showSendMoney, setShowSendMoney] = useState(false)
  const [showCashIn, setShowCashIn] = useState(false)
  const { user } = useAuth()

  const handleBalanceChange = (newBalance: number) => {
    setBalance(isNaN(newBalance) ? 0 : newBalance);
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow-md mb-6 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-center mb-2">
        <h2 className="font-roboto font-semibold text-[#1a237e]">Wallet Balance</h2>
        <Eye className="text-[#1a237e] cursor-pointer hover:text-blue-600 transition-colors" />
      </div>
      <p className="text-2xl font-bold text-[#1a237e]">
        ₱{typeof balance === 'number' 
          ? balance.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})
          : '0.00'}
      </p>
      <div className="flex gap-2 mt-3">
        <button
          onClick={() => user?.isVerified && setShowCashIn(true)}
          className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-2 transition-colors ${
            user?.isVerified 
              ? 'bg-[#1a237e] text-white hover:bg-blue-700' 
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
          disabled={!user?.isVerified}
        >
          <Plus size={16} />
          Cash In
        </button>
        <button
          onClick={() => user?.isVerified && setShowSendMoney(true)}
          className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-2 transition-colors ${
            user?.isVerified 
              ? 'border border-[#1a237e] text-[#1a237e] hover:bg-[#1a237e] hover:text-white' 
              : 'border border-gray-300 text-gray-500 cursor-not-allowed'
          }`}
          disabled={!user?.isVerified}
        >
          <Send size={16} />
          Send
        </button>
      </div>
      {!user?.isVerified && (
        <p className="text-sm text-red-500 mt-2">Verify your account to enable transactions</p>
      )}
      {showSendMoney && (
        <SendMoneyModal
          onClose={() => setShowSendMoney(false)}
          balance={balance}
          onBalanceChange={handleBalanceChange}
        />
      )}
      {showCashIn && (
        <CashInModal
          onClose={() => setShowCashIn(false)}
          onBalanceChange={handleBalanceChange}
        />
      )}
    </div>
  )
}

export default WalletBalance

