import { FC, useState, useEffect } from 'react'
import { collection, query, where, getDocs, doc, updateDoc, increment } from 'firebase/firestore'
import { db } from '../firebase'

interface Transaction {
  id: string
  userId: string
  amount: number
  status: string
}

interface User {
  id: string
  name: string
  email: string
  balance: number
}

const AdminDashboard: FC = () => {
  const [pendingTransactions, setPendingTransactions] = useState<Transaction[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [selectedUser, setSelectedUser] = useState<string>('')
  const [amount, setAmount] = useState<string>('')

  useEffect(() => {
    const fetchPendingTransactions = async () => {
      const q = query(collection(db, 'transactions'), where('status', '==', 'pending'))
      const querySnapshot = await getDocs(q)
      const transactions = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction))
      setPendingTransactions(transactions)
    }

    const fetchUsers = async () => {
      const usersCollection = collection(db, 'users')
      const userSnapshot = await getDocs(usersCollection)
      const userList = userSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as User))
      setUsers(userList)
    }

    fetchPendingTransactions()
    fetchUsers()
  }, [])

  const handleApproveTransaction = async (transaction: Transaction) => {
    try {
      // Update transaction status
      await updateDoc(doc(db, 'transactions', transaction.id), { status: 'approved' })

      // Update user's balance
      await updateDoc(doc(db, 'users', transaction.userId), {
        balance: increment(transaction.amount)
      })

      // Remove the transaction from the list
      setPendingTransactions(pendingTransactions.filter(t => t.id !== transaction.id))
    } catch (error) {
      console.error('Error approving transaction:', error)
    }
  }

  const handleAddBalance = async () => {
    if (!selectedUser || !amount) return

    try {
      await updateDoc(doc(db, 'users', selectedUser), {
        balance: increment(parseFloat(amount))
      })

      alert('Balance added successfully')
      setSelectedUser('')
      setAmount('')
    } catch (error) {
      console.error('Error adding balance:', error)
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-4">Pending Cash In Requests</h2>
        {pendingTransactions.map(transaction => (
          <div key={transaction.id} className="bg-white p-4 rounded-lg shadow mb-4">
            <p>User ID: {transaction.userId}</p>
            <p>Amount: ₱{transaction.amount.toFixed(2)}</p>
            <button
              onClick={() => handleApproveTransaction(transaction)}
              className="mt-2 bg-green-500 text-white px-4 py-2 rounded"
            >
              Approve
            </button>
          </div>
        ))}
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-4">Add Balance to User</h2>
        <div className="space-y-4">
          <select
            value={selectedUser}
            onChange={(e) => setSelectedUser(e.target.value)}
            className="w-full p-2 border rounded"
          >
            <option value="">Select a user</option>
            {users.map(user => (
              <option key={user.id} value={user.id}>{user.name} ({user.email})</option>
            ))}
          </select>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="Amount"
            className="w-full p-2 border rounded"
          />
          <button
            onClick={handleAddBalance}
            className="bg-blue-500 text-white px-4 py-2 rounded"
          >
            Add Balance
          </button>
        </div>
      </div>
    </div>
  )
}

export default AdminDashboard

