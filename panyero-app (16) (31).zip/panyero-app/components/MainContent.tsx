'use client'

import { useState } from 'react'
import Header from './Header'
import WalletBalance from './WalletBalance'
import KapitanNiyero from './KapitanNiyero'
import QuickAccess from './QuickAccess'
import RecentTransactions from './RecentTransactions'
import UserProfiles from './UserProfiles'
import NavigationButtons from './NavigationButtons'

export default function MainContent() {
  const [balance, setBalance] = useState<number>(50000)
  const [userLevel, setUserLevel] = useState(5)

  return (
    <div className="space-y-6">
      <Header userLevel={userLevel} />
      <WalletBalance initialBalance={balance} />
      <KapitanNiyero />
      <QuickAccess />
      <RecentTransactions />
      <UserProfiles />
      <NavigationButtons weatherAlert="Clear skies ahead" />
    </div>
  )
}

