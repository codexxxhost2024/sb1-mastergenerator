'use client'

import { FC } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, CreditCard, QrCode, Ship, User } from 'lucide-react'

const NavigationBar: FC = () => {
  const pathname = usePathname()

  const navItems = [
    { icon: Home, label: 'Home', href: '/' },
    { icon: CreditCard, label: 'E-Services', href: '/eservices' },
    { icon: QrCode, label: 'Scan', href: '/scan' },
    { icon: Ship, label: 'Maritime', href: '/maritime' },
    { icon: User, label: 'Profile', href: '/profile' },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white shadow-lg p-2 transition-all duration-200 hover:bg-gray-50">
      <div className="flex justify-around items-center">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`text-center cursor-pointer transform transition-all duration-200 hover:-translate-y-1 hover:text-[#1a237e] ${
              item.href === '/scan' ? '-mt-6' : ''
            }`}
          >
            <div
              className={`${
                item.href === '/scan'
                  ? 'bg-[#1a237e] text-white rounded-full p-4 shadow-lg hover:bg-[#3949ab] transition-all duration-200'
                  : 'p-2'
              }`}
            >
              <item.icon
                className={`${
                  pathname === item.href ? 'text-[#1a237e]' : 'text-gray-500'
                } transition-colors duration-200 ${
                  item.href === '/scan' ? 'h-8 w-8 text-white' : 'h-6 w-6'
                }`}
              />
            </div>
            <span className={`text-xs mt-1 block transition-colors duration-200 ${
              pathname === item.href ? 'text-[#1a237e]' : 'text-gray-500'
            }`}>
              {item.label}
            </span>
          </Link>
        ))}
      </div>
    </nav>
  )
}

export default NavigationBar

