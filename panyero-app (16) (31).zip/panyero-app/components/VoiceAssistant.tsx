'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'

const VoiceAssistant = () => {
  const [isVisible, setIsVisible] = useState(true)
  const [lastScrollY, setLastScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY
      if (currentScrollY > lastScrollY) {
        setIsVisible(false)
      } else {
        setIsVisible(true)
      }
      setLastScrollY(currentScrollY)
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [lastScrollY])

  return (
    <div 
      className={`fixed bottom-24 right-4 transition-all duration-300 ease-in-out ${
        isVisible ? 'translate-y-0 opacity-100' : 'translate-y-16 opacity-0'
      }`}
    >
      <div className="relative w-16 h-16 animate-float">
        <Image 
          src="https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/home-alligned-services-app-pmoowx/assets/or8azqiuge1e/Screenshot_2024-12-05_at_9.17.02_PM.png" 
          alt="Voice assistant avatar" 
          width={64}
          height={64}
          className="rounded-full shadow-lg cursor-pointer hover:scale-110 transition-transform"
        />
        <div className="absolute inset-0 bg-blue-500 rounded-full animate-pulse opacity-30"></div>
      </div>
    </div>
  )
}

export default VoiceAssistant

