'use client'

import { FC, useEffect, useState } from 'react'
import { ArrowUp, ArrowDown } from 'lucide-react'
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore'
import { db } from '../firebase'

interface Transaction {
  id: string
  type: 'send' | 'receive'
  amount: number
  title: string
  timestamp: { seconds: number }
}

const RecentTransactions: FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([])

  useEffect(() => {
    const q = query(collection(db, 'transactions'), orderBy('timestamp', 'desc'), limit(5))
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const transactionsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Transaction))
      setTransactions(transactionsData)
    })

    return () => unsubscribe()
  }, [])

  return (
    <div className="bg-white rounded-xl shadow-md p-4 mb-6 hover:shadow-lg transition-shadow">
      <h3 className="font-roboto font-semibold mb-4 text-[#1a237e]">Recent Transactions</h3>
      <div className="space-y-4">
        {transactions.map((transaction) => (
          <div key={transaction.id} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg transition-colors">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${transaction.type === 'send' ? 'bg-red-100' : 'bg-green-100'}`}>
                {transaction.type === 'send' ? (
                  <ArrowUp className="text-red-500" />
                ) : (
                  <ArrowDown className="text-green-500" />
                )}
              </div>
              <div>
                <p className="font-semibold">{transaction.title}</p>
                <p className="text-sm text-gray-500">
                  {transaction.timestamp?.seconds
                    ? new Date(transaction.timestamp.seconds * 1000).toLocaleDateString()
                    : 'Date not available'}
                </p>
              </div>
            </div>
            <p className={`font-semibold ${transaction.type === 'send' ? 'text-red-500' : 'text-green-500'}`}>
              {transaction.type === 'send' ? '-' : '+'} ₱{transaction.amount.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default RecentTransactions

