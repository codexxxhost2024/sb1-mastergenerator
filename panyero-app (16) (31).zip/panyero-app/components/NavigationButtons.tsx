import { FC } from 'react'
import Link from 'next/link'
import { Wallet, Compass, ShieldCheck, Dice1Icon as Dice } from 'lucide-react'

interface NavigationButtonsProps {
  weatherAlert: string
}

const NavigationButtons: FC<NavigationButtonsProps> = ({ weatherAlert }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
      <NavigationButton icon={<Wallet />} title="Wallet" description="Quick transfers" href="/wallet" />
      <NavigationButton icon={<Compass />} title="Navigation" description={weatherAlert} href="/navigation" />
      <NavigationButton icon={<ShieldCheck />} title="Safety" description="Protocols & guides" href="/safety" />
      <NavigationButton icon={<Dice />} title="Entertainment" description="Games & betting" href="/entertainment" />
    </div>
  )
}

const NavigationButton: FC<{ icon: React.ReactNode; title: string; description: string; href: string }> = ({ icon, title, description, href }) => {
  return (
    <Link href={href} className="bg-white p-4 rounded-xl shadow-md hover:shadow-lg transition-shadow hover:-translate-y-1 cursor-pointer">
      {React.cloneElement(icon as React.ReactElement, { className: "text-3xl text-[#1a237e] mb-2" })}
      <h2 className="font-roboto font-semibold">{title}</h2>
      <p className="text-sm text-gray-600">{description}</p>
    </Link>
  )
}

export default NavigationButtons

