import { FC, useState } from 'react'
import Image from 'next/image'
import { Settings, Edit, LogOut, Camera, Lock } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { useRouter } from 'next/navigation'
import CameraCapture from './CameraCapture'
import { doc, updateDoc } from 'firebase/firestore'
import { db } from '../firebase'

const UserProfile: FC = () => {
  const { user, setUser } = useAuth()
  const [isVerified, setIsVerified] = useState(user?.isVerified || false)
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false)
  const [adminPassword, setAdminPassword] = useState('')
  const [isCameraOpen, setIsCameraOpen] = useState(false)
  const router = useRouter()

  const handleVerification = async () => {
    setIsCameraOpen(true)
  }

  const handleImageCapture = async (imageData: string) => {
    if (user) {
      const userRef = doc(db, 'users', user.id)
      await updateDoc(userRef, { 
        photoURL: imageData,
        isVerified: true
      })
      setUser({ ...user, photoURL: imageData, isVerified: true })
      setIsVerified(true)
    }
    setIsCameraOpen(false)
  }

  const handleAdminAccess = () => {
    setIsAdminModalOpen(true)
  }

  const handleAdminPasswordSubmit = () => {
    if (adminPassword === 'Halanakalimutanko') {
      setIsAdminModalOpen(false)
      router.push('/admin')
    } else {
      alert('Incorrect password')
    }
  }

  return (
    <div className="bg-white rounded-xl shadow-md p-6 mb-6">
      <div className="flex items-center mb-6">
        <Image
          src={user?.photoURL || "/placeholder.svg?height=100&width=100"}
          alt="User Avatar"
          width={100}
          height={100}
          className="rounded-full mr-4"
        />
        <div>
          <h2 className="text-2xl font-bold text-[#1a237e]">{user?.displayName || 'New User'}</h2>
          <p className="text-gray-600">{user?.email}</p>
          <p className={`text-sm ${isVerified ? 'text-green-500' : 'text-red-500'}`}>
            {isVerified ? 'Verified' : 'Not Verified'}
          </p>
        </div>
      </div>
      <div className="space-y-4">
        <Link href="/settings" className="flex items-center p-3 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
          <Settings className="mr-3" />
          <span>Account Settings</span>
        </Link>
        <button
          onClick={handleVerification}
          className="flex items-center p-3 rounded-lg bg-blue-500 text-white hover:bg-blue-600 transition-colors w-full"
        >
          <Camera className="mr-3" />
          <span>{isVerified ? 'Re-verify Account' : 'Verify Account'}</span>
        </button>
        <Button onClick={handleAdminAccess} className="w-full">
          <Lock className="mr-2" />
          Admin Access
        </Button>
      </div>

      <Dialog open={isAdminModalOpen} onOpenChange={setIsAdminModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Admin Access</DialogTitle>
            <DialogDescription>
              Please enter the admin password to access the admin page.
            </DialogDescription>
          </DialogHeader>
          <Input
            type="password"
            placeholder="Enter admin password"
            value={adminPassword}
            onChange={(e) => setAdminPassword(e.target.value)}
          />
          <DialogFooter>
            <Button onClick={handleAdminPasswordSubmit}>Submit</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {isCameraOpen && (
        <CameraCapture
          onCapture={handleImageCapture}
          onClose={() => setIsCameraOpen(false)}
        />
      )}
    </div>
  )
}

export default UserProfile

