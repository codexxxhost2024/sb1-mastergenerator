import { FC } from 'react'
import Link from 'next/link'
import { Book, Hotel, Ship, CloudSun, MapPin, Gift, LifeBuoy, Settings } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'

const quickAccessItems = [
  { icon: Book, label: 'Review', section: 'review' },
  { icon: Hotel, label: 'Booking', section: 'booking' },
  { icon: Ship, label: 'Ship Info', section: 'ship-info' },
  { icon: CloudSun, label: 'Weather', section: 'weather' },
  { icon: MapPin, label: 'GPS', section: 'gps' },
  { icon: Gift, label: 'Rewards', section: 'rewards' },
  { icon: LifeBuoy, label: 'Help', section: 'help' },
  { icon: Settings, label: 'Settings', section: 'settings' },
]

const QuickAccess: FC = () => {
  const { user } = useAuth()

  return (
    <div className="bg-white p-4 rounded-xl shadow-md hover:shadow-lg transition-shadow mb-6">
      <h3 className="font-roboto font-semibold mb-4 text-[#1a237e]">Quick Access</h3>
      <div className="grid grid-cols-4 md:grid-cols-8 gap-4">
        {quickAccessItems.map((item, index) => (
          <Link
            key={index}
            href={user?.isAffiliate ? `/${item.section}` : '#'}
            className={`text-center cursor-pointer hover:bg-gray-100 p-2 rounded-lg transition-colors ${
              !user?.isAffiliate ? 'opacity-50 pointer-events-none' : ''
            }`}
          >
            <div className="bg-[#f8f9fa] p-3 rounded-lg mb-1">
              <item.icon className="text-xl text-[#1a237e]" />
            </div>
            <p className="text-xs">{item.label}</p>
          </Link>
        ))}
      </div>
      {!user?.isAffiliate && (
        <p className="text-sm text-red-500 mt-4">Activate your account to access all services</p>
      )}
    </div>
  )
}

export default QuickAccess

