import { FC } from 'react'
import { Anchor, Map, CloudSun, Waves, AlertTriangle, FileText, Users, Package, Fuel, PenToolIcon as Tool, Radio, FileIcon, Umbrella, Award } from 'lucide-react'

const maritimeServices = [
  { icon: Map, title: 'Navigation' },
  { icon: CloudSun, title: 'Weather' },
  { icon: Waves, title: 'Tides' },
  { icon: Anchor, title: 'Port Info' },
  { icon: AlertTriangle, title: 'SOS' },
  { icon: FileText, title: 'Logs' },
  { icon: Users, title: 'Crew Mgmt' },
  { icon: Package, title: 'Cargo Tracking' },
  { icon: Fuel, title: 'Fuel Mgmt' },
  { icon: Tool, title: 'Maintenance' },
  { icon: Radio, title: 'Communications' },
  { icon: FileIcon, title: 'Documentation' },
  { icon: Umbrella, title: 'Insurance' },
  { icon: Award, title: 'Certifications' },
]

const MaritimeServices: FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-[#1a237e]">Maritime Services</h1>
      <div className="grid grid-cols-2 gap-4">
        {maritimeServices.map((service, index) => (
          <div key={index} className="flex flex-col items-center justify-center p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <service.icon className="w-8 h-8 text-[#1a237e] mb-2" />
            <span className="text-sm font-medium text-center">{service.title}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export default MaritimeServices

