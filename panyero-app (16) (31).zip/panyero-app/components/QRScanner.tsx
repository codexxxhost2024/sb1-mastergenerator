'use client'

import { useState } from 'react'
import dynamic from 'next/dynamic'
import { AlertCircle } from 'lucide-react'

const QrReader = dynamic(() => import('@yudiel/react-qr-scanner'), { ssr: false })

const QRScanner = () => {
  const [result, setResult] = useState('')
  const [error, setError] = useState<string | null>(null)

  const handleScan = (data: string | null) => {
    if (data) {
      setResult(data)
    }
  }

  const handleError = (err: Error) => {
    setError(err.message)
  }

  return (
    <div className="flex flex-col items-center justify-center space-y-4">
      <h2 className="text-2xl font-bold text-[#1a237e]">QR Scanner</h2>
      <div className="w-full max-w-md aspect-square">
        {error ? (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        ) : (
          <QrReader
            onResult={(result) => {
              if (result) {
                handleScan(result.getText())
              }
            }}
            onError={handleError}
            constraints={{ facingMode: 'environment' }}
            className="w-full h-full"
          />
        )}
      </div>
      {result && (
        <div className="mt-4 p-4 bg-white rounded-lg shadow w-full max-w-md">
          <h3 className="font-semibold text-lg mb-2">Scanned Result:</h3>
          <p className="break-all">{result}</p>
        </div>
      )}
      <p className="text-sm text-gray-600">
        <AlertCircle className="inline-block mr-1" size={16} />
        Point your camera at a QR code to scan
      </p>
    </div>
  )
}

export default QRScanner

