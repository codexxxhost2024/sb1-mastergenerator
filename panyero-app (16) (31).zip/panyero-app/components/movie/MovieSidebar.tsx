'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Film, Music } from 'lucide-react'

const movieCategories = [
  'Adventure',
  'Fantasy',
  'Animation',
  'Drama',
  'Horror',
  'Action',
  'Comedy',
  'History',
  'Western',
  'Thriller',
  'Crime',
  'Documentary',
  'Science Fiction',
  'Mystery',
  'Music',
  'Romance',
  'Family',
  'War',
  'TV Movie'
]

const musicCategories = [
  'English',
  'Rated 18+'
]

export default function MovieSidebar() {
  const [activeCategory, setActiveCategory] = useState<string>('Adventure')

  return (
    <aside className="w-64 bg-[#1a1a1a] h-screen overflow-y-auto flex-shrink-0">
      <div className="p-4">
        <div className="mb-6">
          <h2 className="flex items-center text-gray-200 font-semibold mb-4">
            <Film className="mr-2" size={20} />
            Movie & Music
          </h2>
          <div className="space-y-2">
            {movieCategories.map((category) => (
              <Link
                key={category}
                href={`/movie/category/${category.toLowerCase()}`}
                className={`block px-3 py-2 rounded-lg transition-colors ${
                  activeCategory === category
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:bg-[#2a2a2a] hover:text-gray-200'
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </Link>
            ))}
          </div>
        </div>
        
        <div>
          <h2 className="flex items-center text-gray-200 font-semibold mb-4">
            <Music className="mr-2" size={20} />
            Music
          </h2>
          <div className="space-y-2">
            {musicCategories.map((category) => (
              <Link
                key={category}
                href={`/movie/music/${category.toLowerCase()}`}
                className={`block px-3 py-2 rounded-lg transition-colors ${
                  activeCategory === category
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:bg-[#2a2a2a] hover:text-gray-200'
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </aside>
  )
}

