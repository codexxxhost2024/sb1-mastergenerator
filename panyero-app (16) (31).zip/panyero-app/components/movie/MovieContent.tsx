'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { Play, Info } from 'lucide-react'

interface Movie {
  id: string
  title: string
  posterUrl: string
  genre: string
  rating: number
}

export default function MovieContent() {
  return (
    <div className="flex-1 h-full">
      <iframe
        src="https://panyero.website/movie"
        className="w-full h-full border-none"
        title="Panyero Movie"
        allowFullScreen
      />
    </div>
  )
}

