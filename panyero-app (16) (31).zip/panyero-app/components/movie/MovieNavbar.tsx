import Image from 'next/image'
import { Search } from 'lucide-react'

export default function MovieNavbar() {
  return (
    <nav className="bg-[#1a1a1a] h-16 flex items-center justify-between px-6 border-b border-gray-800">
      <div className="flex items-center">
        <Image
          src="/panyero-logo.png" // Replace with actual logo path
          alt="Panyero"
          width={120}
          height={40}
          className="mr-4"
        />
      </div>
      <div className="relative flex-1 max-w-xl ml-8">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
        <input
          type="search"
          placeholder="Search any movies..."
          className="w-full bg-[#2a2a2a] text-gray-200 pl-10 pr-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>
    </nav>
  )
}

