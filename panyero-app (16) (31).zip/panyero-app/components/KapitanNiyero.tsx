import { FC } from 'react'
import { Anchor } from 'lucide-react'

const KapitanNiyero: FC = () => {
  return (
    <div className="bg-[#1a237e] p-4 rounded-xl shadow-md mb-6 text-white hover:bg-[#3949ab] transition-colors">
      <div className="flex items-center gap-2 mb-2">
        <Anchor size={24} className="text-white" />
        <h2 className="font-roboto font-semibold">Kapitan Niyero</h2>
      </div>
      <p className="text-sm mb-3">How can I assist you today, ka-Panyero?</p>
      <div className="flex gap-2">
        <button className="bg-white/20 px-3 py-1 rounded-full text-sm hover:bg-white/30 transition-colors">Weather Update</button>
        <button className="bg-white/20 px-3 py-1 rounded-full text-sm hover:bg-white/30 transition-colors">Route Check</button>
      </div>
    </div>
  )
}

export default KapitanNiyero

