import Image from 'next/image'

const LazyLoader = () => {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-white z-50">
      <Image
        src="https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/home-alligned-services-app-pmoowx/assets/b06megjh7jdt/panyero.gif"
        alt="Loading..."
        width={200}
        height={200}
        className="rounded-full"
      />
    </div>
  )
}

export default LazyLoader

