'use client'

import { FC, useEffect, useState } from 'react'
import Image from 'next/image'
import { collection, query, where, getDocs } from 'firebase/firestore'
import { db } from '../firebase'
import { useAuth } from '../contexts/AuthContext'

interface User {
  id: string
  name: string
  email: string
  photoURL: string
}

const UserProfiles: FC = () => {
  const [users, setUsers] = useState<User[]>([])
  const { user } = useAuth()

  useEffect(() => {
    const fetchUsers = async () => {
      const q = query(collection(db, 'users'), where('email', '!=', user?.email))
      const querySnapshot = await getDocs(q)
      const usersData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as User))
      setUsers(usersData)
    }

    if (user) {
      fetchUsers()
    }
  }, [user])

  return (
    <div className="overflow-x-auto mb-6">
      <div className="flex gap-4 p-2">
        {users.map((user) => (
          <div key={user.id} className="flex-shrink-0 text-center cursor-pointer hover:bg-gray-100 p-2 rounded-lg transition-colors">
            <div className="w-16 h-16 rounded-full overflow-hidden mb-1">
              <Image 
                src={user.photoURL || "https://imgcdn.stablediffusionweb.com/2024/11/10/f53426a1-a6a4-4bea-84d4-1345955929b3.jpg"} 
                alt={user.name} 
                width={64} 
                height={64} 
                className="w-full h-full object-cover"
              />
            </div>
            <p className="text-xs text-center truncate w-16">{user.name}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default UserProfiles

