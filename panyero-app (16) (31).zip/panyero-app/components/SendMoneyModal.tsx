import { useState, FC, useEffect } from 'react'
import Image from 'next/image'
import { db } from '../firebase'
import { collection, addDoc, serverTimestamp, updateDoc, doc, increment, getDocs } from 'firebase/firestore'
import { useAuth } from '../contexts/AuthContext'

interface SendMoneyModalProps {
  onClose: () => void
  balance: number
  onBalanceChange: (newBalance: number) => void
}

interface User {
  id: string
  name: string
  email: string
  photoURL: string
  isVerified: boolean
}

const SendMoneyModal: FC<SendMoneyModalProps> = ({ onClose, balance, onBalanceChange }) => {
  const [amount, setAmount] = useState<number | ''>('')
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [users, setUsers] = useState<User[]>([])
  const { user } = useAuth()

  useEffect(() => {
    const fetchUsers = async () => {
      const usersCollection = collection(db, 'users')
      const userSnapshot = await getDocs(usersCollection)
      const userList = userSnapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() } as User))
        .filter(u => u.email !== user?.email && u.isVerified)
      setUsers(userList)
    }

    fetchUsers()
  }, [user])

  const handleSendMoney = async () => {
    if (!selectedUser || amount === '') return
    if (parseFloat(amount.toString()) > balance) {
      setError('Insufficient balance')
      return
    }

    try {
      const newBalance = balance - parseFloat(amount.toString())
      
      // Add transaction to Firestore
      await addDoc(collection(db, 'transactions'), {
        type: 'send',
        amount: parseFloat(amount.toString()),
        title: `Sent to ${selectedUser.name}`,
        timestamp: serverTimestamp(),
        senderId: user?.uid,
        recipientId: selectedUser.id,
      })

      // Update sender's balance in Firestore
      const senderRef = doc(db, 'users', user?.uid || '')
      await updateDoc(senderRef, {
        balance: increment(-parseFloat(amount.toString()))
      })

      // Update recipient's balance in Firestore
      const recipientRef = doc(db, 'users', selectedUser.id)
      await updateDoc(recipientRef, {
        balance: increment(parseFloat(amount.toString()))
      })

      onBalanceChange(newBalance)
      onClose()
    } catch (error) {
      console.error('Error sending money:', error)
      setError('Failed to send money. Please try again.')
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl p-6 w-full max-w-md hover:shadow-lg transition-shadow">
        <h3 className="font-roboto font-semibold text-[#1a237e] mb-4">Send Money</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm mb-2">Select Recipient</label>
            <select
              className="w-full p-2 border rounded-lg text-gray-800"
              value={selectedUser?.id || ''}
              onChange={(e) => setSelectedUser(users.find(u => u.id === e.target.value) || null)}
            >
              <option value="">Select a recipient</option>
              {users.map((user) => (
                <option key={user.id} value={user.id}>{user.name}</option>
              ))}
            </select>
          </div>
          {selectedUser && (
            <div className="flex items-center space-x-4 bg-gray-100 p-4 rounded-lg">
              <Image
                src={selectedUser.photoURL || "/placeholder.svg?height=40&width=40"}
                alt={selectedUser.name}
                width={40}
                height={40}
                className="rounded-full"
              />
              <div>
                <p className="font-semibold">{selectedUser.name}</p>
                <p className="text-sm text-gray-600">{selectedUser.email}</p>
              </div>
            </div>
          )}
          <div>
            <label className="block text-sm mb-2">Amount</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value === '' ? '' : parseFloat(e.target.value))}
              className="w-full p-2 border rounded-lg"
              placeholder="Enter amount"
            />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="flex-1 py-2 border border-[#1a237e] text-[#1a237e] rounded-lg hover:bg-[#1a237e] hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSendMoney}
              className="flex-1 py-2 bg-[#1a237e] text-white rounded-lg hover:bg-blue-700 transition-colors"
              disabled={!selectedUser || amount === ''}
            >
              Send Money
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SendMoneyModal

