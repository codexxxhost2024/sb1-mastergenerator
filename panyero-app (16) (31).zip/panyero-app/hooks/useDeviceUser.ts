import { useState, useEffect } from 'react'
import { doc, getDoc, setDoc } from 'firebase/firestore'
import { db } from '../firebase'
import { v4 as uuidv4 } from 'uuid'

export function useDeviceUser() {
  const [deviceId, setDeviceId] = useState<string | null>(null)
  const [user, setUser] = useState<any | null>(null)

  useEffect(() => {
    const getOrCreateDeviceId = async () => {
      let id = localStorage.getItem('deviceId')
      if (!id) {
        id = uuidv4()
        localStorage.setItem('deviceId', id)
      }
      setDeviceId(id)

      const userRef = doc(db, 'users', id)
      const userDoc = await getDoc(userRef)

      if (!userDoc.exists()) {
        const newUser = {
          id,
          createdAt: new Date(),
          displayName: 'New User',
          email: '',
          photoURL: '',
          isVerified: false,
          balance: 0,
        }
        await setDoc(userRef, newUser)
        setUser(newUser)
      } else {
        setUser(userDoc.data())
      }
    }

    getOrCreateDeviceId()
  }, [])

  return { deviceId, user, setUser }
}

